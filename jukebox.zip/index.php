<!DOCTYPE HTML>
<html>
    <head>
        <title>Get start</title>
        <meta http-equiv="Content-type" content="text/html;charset=utf-8"></meta>
        <link rel="stylesheet" type="text/css" href="css/starting.css"></link>
    	<link rel="shortcut icon" href="imgs/logo.ico" />

    </head>
    <body>
        <div align="center" class="logo">
            <img class="logo"  src="imgs/jb2.gif"><br>
            
        </div>
        <div align="center" class="content">
        	<a href="homepage.php"><img src="imgs/two.png" alt="play" height="200" width="210"></a>
        </div>
        <div align="Center" class="footer">
                 Developed by:  Hardik Bamaniya  , Tanzila Bheda  & Subhash Keshwala
        </div>
        </form>
    </body>
</html>
