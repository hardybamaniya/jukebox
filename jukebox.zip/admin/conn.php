<?php

	mysql_connect("localhost","root","") or die("Not connected");
	mysql_select_db("music") or die("db not selected");	
?>