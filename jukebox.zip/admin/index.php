<?php
	header("Location:../homepage.php");
?>